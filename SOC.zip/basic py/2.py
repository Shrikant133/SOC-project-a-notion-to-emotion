from utils import findmax
from ecommerce.shipping import shipping_prize
arr= [1,23,2,32,42,4324,25454,56666,54,234,1111110]

print(findmax(arr))
shipping_prize()