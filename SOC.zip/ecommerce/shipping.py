def shipping_prize():
    print("Shipped now")